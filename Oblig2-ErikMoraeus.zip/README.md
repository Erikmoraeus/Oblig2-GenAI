# Oblig2-GenAI
 Her er mappen for produktet jeg skal lage i Oblig 2 i GenAI faget

 Jeg har opprettet en HTML, Javascript og CSS fil, med to mapper med bilder og lyd.
 I rapport-filen finner du rapporten jeg har skrevet om prossesen. 

 Takk for meg.